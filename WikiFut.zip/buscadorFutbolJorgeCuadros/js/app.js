function mostrarDatos1(method, urlJSON, response, searchData) 
{
    var contenedor0 = document.getElementById("contenedor0")
    var hayJugadores = false

    response.innerHTML = ""

    var xhr = new XMLHttpRequest()
    xhr.onreadystatechange = function()
    {
        if (this.readyState == 4 && this.status == 200)
        {
            const datos1 = this.response
            const datos2 = JSON.parse(datos1)
            const jugadores1 = datos2["jugadores"]

            for (let jugador of jugadores1)
            {
                if (searchData.value.toLowerCase().trim()==jugador.nombre.toLowerCase().trim() || searchData.value.toLowerCase().trim()==jugador.nacionalidad.toLowerCase().trim() || searchData.value.toLowerCase().trim()==jugador.liga.toLowerCase().trim() || searchData.value.toLowerCase().trim()==jugador.equipo.toLowerCase().trim())
                {
                    hayJugadores = true

                    div0 = document.createElement('div')
                    div0.setAttribute('class', 'contenedor2-1')
                    response.appendChild(div0)

                    div1 = document.createElement('div')
                    div1.setAttribute('class', 'contenedor2-1-1')
                    div0.appendChild(div1)

                    div2 = document.createElement('div')
                    div2.setAttribute('class', 'contenedor2-1-1-1')
                    div1.appendChild(div2)

                    h2 = document.createElement('h2')
                    h2.textContent = jugador.nombre
                    h2.setAttribute('class', 'titulo1')
                    div2.appendChild(h2)

                    p = document.createElement('p')
                    p.textContent = jugador.nacionalidad
                    p.setAttribute('class', 'texto1')
                    div2.appendChild(p)

                    p = document.createElement('p')
                    p.textContent = jugador.liga
                    p.setAttribute('class', 'texto1')
                    div2.appendChild(p)

                    p = document.createElement('p')
                    p.textContent = jugador.equipo
                    p.setAttribute('class', 'texto1')
                    div2.appendChild(p)

                    div1 = document.createElement('div')
                    div1.setAttribute('class', 'contenedor2-1-2')
                    div0.appendChild(div1)

                    img = document.createElement('img')
                    img.setAttribute("src", jugador.img)
                    img.setAttribute("alt", jugador.nombre)
                    img.setAttribute('class', 'imagen1')
                    div1.appendChild(img)
                }
            }
            if (hayJugadores==true)
            {
                contenedor0.classList.remove("visible");
                contenedor0.classList.add("oculto");
            }
            else if (hayJugadores==false)
            {
                response.innerHTML = ""
                contenedor0.classList.remove("oculto");
                contenedor0.classList.add("visible");
            }
            searchData.value = ""
        }
    }
    xhr.open(method, urlJSON, true)
    xhr.send()
}

// ---------------------------------- INICIO - AÑADIR EVENTOS

window.addEventListener("load", function()
{
    const b1 = document.getElementById("b1")

    if(b1)
    {
        const response1 = document.getElementById("resultado1")
        const urlJSON = 'json/bd1.json'
        const method1 = 'GET'
        const searchData1 = document.getElementById("c1")

        b1.addEventListener("click", function(event){
            event.preventDefault()
            mostrarDatos1(method1, urlJSON, response1, searchData1)
        })
    }
})